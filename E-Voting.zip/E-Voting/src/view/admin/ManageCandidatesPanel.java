package view.admin;

import controller.ElectionController;
import model.Candidate;
import model.Election;
import utils.UITheme;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.util.List;

/**
 * Panel for managing candidates within elections.
 */
public class ManageCandidatesPanel extends JPanel {

    private JComboBox<Election> electionCombo;
    private JTable candidateTable;
    private DefaultTableModel tableModel;
    private final ElectionController controller;

    /** Constructs the manage candidates panel. */
    public ManageCandidatesPanel() {
        controller = new ElectionController();
        initComponents();
        loadElections();
    }

    /**
     * Initializes all UI components.
     */
    private void initComponents() {
        setLayout(new BorderLayout(0, 15));
        setOpaque(false);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout(10, 0));
        headerPanel.setOpaque(false);

        JLabel title = new JLabel("Manage Candidates");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        headerPanel.add(title, BorderLayout.WEST);

        JPanel rightHeader = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightHeader.setOpaque(false);

        electionCombo = new JComboBox<>();
        electionCombo.setFont(UITheme.FONT_BODY);
        electionCombo.setPreferredSize(new Dimension(250, 35));
        rightHeader.add(new JLabel("Election: "));
        rightHeader.add(electionCombo);

        JButton addButton = UITheme.createPrimaryButton("+ Add Candidate");
        addButton.addActionListener(e -> showCandidateDialog(null));
        rightHeader.add(addButton);

        headerPanel.add(rightHeader, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Name", "Party", "Bio", "Photo"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        candidateTable = new JTable(tableModel);
        candidateTable.setFont(UITheme.FONT_TABLE);
        candidateTable.setRowHeight(32);
        candidateTable.getTableHeader().setFont(UITheme.FONT_BUTTON);
        candidateTable.getTableHeader().setBackground(UITheme.PRIMARY);
        candidateTable.getTableHeader().setForeground(Color.WHITE);
        candidateTable.setSelectionBackground(UITheme.PRIMARY_LIGHT);
        candidateTable.setSelectionForeground(Color.WHITE);
        candidateTable.setGridColor(new Color(0xE0, 0xE0, 0xE0));

        // Set column widths
        candidateTable.getColumnModel().getColumn(3).setPreferredWidth(200);

        JScrollPane scrollPane = new JScrollPane(candidateTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0, 0xE0, 0xE0)));
        add(scrollPane, BorderLayout.CENTER);

        // Actions
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        actionPanel.setOpaque(false);
        JButton editButton = UITheme.createAccentButton("Edit");
        JButton deleteButton = UITheme.createDangerButton("Delete");

        editButton.addActionListener(e -> editSelected());
        deleteButton.addActionListener(e -> deleteSelected());

        actionPanel.add(editButton);
        actionPanel.add(deleteButton);
        add(actionPanel, BorderLayout.SOUTH);

        // Load candidates when election changes
        electionCombo.addActionListener(e -> loadCandidates());
    }

    /**
     * Loads elections into the combo box.
     */
    private void loadElections() {
        SwingWorker<List<Election>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Election> doInBackground() {
                return controller.getAllElections();
            }

            @Override
            protected void done() {
                try {
                    electionCombo.removeAllItems();
                    for (Election el : get()) {
                        electionCombo.addItem(el);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /**
     * Loads candidates for the selected election.
     */
    private void loadCandidates() {
        Election selected = (Election) electionCombo.getSelectedItem();
        if (selected == null) return;

        SwingWorker<List<Candidate>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Candidate> doInBackground() {
                return controller.getCandidates(selected.getElectionId());
            }

            @Override
            protected void done() {
                try {
                    tableModel.setRowCount(0);
                    for (Candidate c : get()) {
                        String bioTruncated = c.getBio() != null && c.getBio().length() > 50
                                ? c.getBio().substring(0, 50) + "..." : c.getBio();
                        tableModel.addRow(new Object[]{
                            c.getCandidateId(),
                            c.getFullName(),
                            c.getParty(),
                            bioTruncated,
                            c.getPhotoPath() != null ? "Yes" : "No"
                        });
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /**
     * Shows the add/edit candidate dialog.
     *
     * @param existingCandidate the candidate to edit, or null for a new one
     */
    private void showCandidateDialog(Candidate existingCandidate) {
        Election selected = (Election) electionCombo.getSelectedItem();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Please select an election first.", "No Election", JOptionPane.WARNING_MESSAGE);
            return;
        }

        boolean isEdit = (existingCandidate != null);
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(this),
                isEdit ? "Edit Candidate" : "Add Candidate",
                Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setSize(450, 500);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel electionLabel = new JLabel("Election: " + selected.getTitle());
        electionLabel.setFont(UITheme.FONT_SUBTITLE);

        JTextField nameField = UITheme.createTextField();
        JTextField partyField = UITheme.createTextField();
        JTextArea bioArea = new JTextArea(4, 20);
        bioArea.setFont(UITheme.FONT_BODY);
        bioArea.setLineWrap(true);
        bioArea.setWrapStyleWord(true);

        JLabel photoLabel = new JLabel("No photo selected");
        photoLabel.setFont(UITheme.FONT_SMALL);
        JButton browseButton = UITheme.createPrimaryButton("Browse Photo");
        final String[] photoPath = {null};

        JLabel previewLabel = new JLabel();
        previewLabel.setPreferredSize(new Dimension(80, 80));

        if (isEdit) {
            nameField.setText(existingCandidate.getFullName());
            partyField.setText(existingCandidate.getParty());
            bioArea.setText(existingCandidate.getBio());
            if (existingCandidate.getPhotoPath() != null) {
                photoPath[0] = existingCandidate.getPhotoPath();
                photoLabel.setText(new File(existingCandidate.getPhotoPath()).getName());
                loadPhotoPreview(previewLabel, existingCandidate.getPhotoPath());
            }
        }

        browseButton.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setFileFilter(new FileNameExtensionFilter("Image files", "png", "jpg", "jpeg", "gif"));
            if (chooser.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                photoPath[0] = file.getAbsolutePath();
                photoLabel.setText(file.getName());
                loadPhotoPreview(previewLabel, file.getAbsolutePath());
            }
        });

        int row = 0;
        gbc.gridy = row++;
        panel.add(electionLabel, gbc);
        gbc.gridy = row++;
        panel.add(new JLabel("Full Name:"), gbc);
        gbc.gridy = row++;
        panel.add(nameField, gbc);
        gbc.gridy = row++;
        panel.add(new JLabel("Party:"), gbc);
        gbc.gridy = row++;
        panel.add(partyField, gbc);
        gbc.gridy = row++;
        panel.add(new JLabel("Bio:"), gbc);
        gbc.gridy = row++;
        panel.add(new JScrollPane(bioArea), gbc);
        gbc.gridy = row++;
        panel.add(new JLabel("Photo:"), gbc);
        gbc.gridy = row++;
        JPanel photoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        photoPanel.add(browseButton);
        photoPanel.add(photoLabel);
        panel.add(photoPanel, gbc);
        gbc.gridy = row++;
        panel.add(previewLabel, gbc);

        JButton saveButton = UITheme.createPrimaryButton(isEdit ? "Update" : "Save");
        gbc.gridy = row;
        gbc.insets = new Insets(15, 5, 5, 5);
        panel.add(saveButton, gbc);

        dialog.setContentPane(new JScrollPane(panel));

        saveButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Name is required.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Candidate c = isEdit ? existingCandidate : new Candidate();
            c.setElectionId(selected.getElectionId());
            c.setFullName(name);
            c.setParty(partyField.getText().trim());
            c.setBio(bioArea.getText().trim());
            c.setPhotoPath(photoPath[0]);

            SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() {
                    return isEdit ? controller.updateCandidate(c) : controller.addCandidate(c);
                }

                @Override
                protected void done() {
                    try {
                        if (get()) {
                            dialog.dispose();
                            loadCandidates();
                        } else {
                            JOptionPane.showMessageDialog(dialog, "Operation failed.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            worker.execute();
        });

        dialog.setVisible(true);
    }

    /** Loads a photo preview into a label. */
    private void loadPhotoPreview(JLabel label, String path) {
        try {
            ImageIcon icon = new ImageIcon(path);
            Image img = icon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
            label.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            label.setIcon(null);
            label.setText("Preview error");
        }
    }

    /** Edits the selected candidate. */
    private void editSelected() {
        int row = candidateTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a candidate to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        Election selected = (Election) electionCombo.getSelectedItem();
        if (selected == null) return;

        SwingWorker<List<Candidate>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Candidate> doInBackground() {
                return controller.getCandidates(selected.getElectionId());
            }

            @Override
            protected void done() {
                try {
                    for (Candidate c : get()) {
                        if (c.getCandidateId() == id) {
                            showCandidateDialog(c);
                            return;
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /** Deletes the selected candidate with confirmation. */
    private void deleteSelected() {
        int row = candidateTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a candidate to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        String name = (String) tableModel.getValueAt(row, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete candidate \"" + name + "\"?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() {
                    return controller.deleteCandidate(id);
                }

                @Override
                protected void done() {
                    try {
                        if (get()) {
                            loadCandidates();
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            worker.execute();
        }
    }
}
