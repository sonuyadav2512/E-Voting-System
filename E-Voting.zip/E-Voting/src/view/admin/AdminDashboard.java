package view.admin;

import controller.AdminController;
import controller.ElectionController;
import controller.VoteController;
import model.User;
import utils.SessionManager;
import utils.UITheme;
import view.LoginFrame;

import javax.swing.*;
import java.awt.*;

/**
 * Admin dashboard with sidebar navigation, stats cards, and tabbed management panels.
 */
public class AdminDashboard extends JFrame {

    private JPanel contentPanel;
    private JLabel welcomeLabel;
    private final ElectionController electionController;
    private final AdminController adminController;
    private final VoteController voteController;
    private JButton activeNavButton;

    /**
     * Constructs the admin dashboard.
     */
    public AdminDashboard() {
        electionController = new ElectionController();
        adminController = new AdminController();
        voteController = new VoteController();
        initComponents();
        showDashboard();
    }

    /**
     * Initializes and lays out all UI components.
     */
    private void initComponents() {
        setTitle("E-Voting System - Admin Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 700);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UITheme.BG_LIGHT);

        // ─── Top Bar ────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UITheme.PRIMARY);
        topBar.setPreferredSize(new Dimension(0, 55));
        topBar.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        User currentUser = SessionManager.getCurrentUser();
        welcomeLabel = new JLabel("Welcome, " + (currentUser != null ? currentUser.getFullName() : "Admin"));
        welcomeLabel.setFont(UITheme.FONT_SUBTITLE);
        welcomeLabel.setForeground(Color.WHITE);
        topBar.add(welcomeLabel, BorderLayout.WEST);

        JButton logoutButton = UITheme.createDangerButton("Logout");
        logoutButton.setPreferredSize(new Dimension(90, 32));
        JPanel logoutPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 10));
        logoutPanel.setOpaque(false);
        logoutPanel.add(logoutButton);
        topBar.add(logoutPanel, BorderLayout.EAST);

        mainPanel.add(topBar, BorderLayout.NORTH);

        // ─── Sidebar ───────────────────────────────
        JPanel sidebar = new JPanel();
        sidebar.setBackground(UITheme.SIDEBAR_BG);
        sidebar.setPreferredSize(new Dimension(UITheme.SIDEBAR_WIDTH, 0));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));

        JLabel appLabel = new JLabel("  \u2611 E-Voting Admin");
        appLabel.setFont(UITheme.FONT_TITLE);
        appLabel.setForeground(UITheme.ACCENT);
        appLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        appLabel.setBorder(BorderFactory.createEmptyBorder(5, 15, 20, 15));
        sidebar.add(appLabel);

        JButton dashBtn = createNavButton("\u2302  Dashboard");
        JButton electionsBtn = createNavButton("\u2610  Elections");
        JButton candidatesBtn = createNavButton("\u263A  Candidates");
        JButton votersBtn = createNavButton("\u2603  Voters");
        JButton reportsBtn = createNavButton("\u2605  Reports");

        sidebar.add(dashBtn);
        sidebar.add(electionsBtn);
        sidebar.add(candidatesBtn);
        sidebar.add(votersBtn);
        sidebar.add(reportsBtn);
        sidebar.add(Box.createVerticalGlue());

        mainPanel.add(sidebar, BorderLayout.WEST);

        // ─── Content Area ──────────────────────────
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(UITheme.BG_LIGHT);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        setContentPane(mainPanel);

        // ─── Event handlers ────────────────────────
        dashBtn.addActionListener(e -> { setActiveNav(dashBtn); showDashboard(); });
        electionsBtn.addActionListener(e -> { setActiveNav(electionsBtn); showElections(); });
        candidatesBtn.addActionListener(e -> { setActiveNav(candidatesBtn); showCandidates(); });
        votersBtn.addActionListener(e -> { setActiveNav(votersBtn); showVoters(); });
        reportsBtn.addActionListener(e -> { setActiveNav(reportsBtn); showReports(); });

        logoutButton.addActionListener(e -> logout());

        setActiveNav(dashBtn);
    }

    /**
     * Creates a navigation button for the sidebar.
     *
     * @param text the button text
     * @return the styled sidebar button
     */
    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setFont(UITheme.FONT_BODY);
        button.setForeground(UITheme.SIDEBAR_TEXT);
        button.setBackground(UITheme.SIDEBAR_BG);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        button.setPreferredSize(new Dimension(UITheme.SIDEBAR_WIDTH, 42));
        button.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 15));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (button != activeNavButton) {
                    button.setBackground(UITheme.PRIMARY_LIGHT);
                }
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                if (button != activeNavButton) {
                    button.setBackground(UITheme.SIDEBAR_BG);
                }
            }
        });
        return button;
    }

    /**
     * Sets the active navigation button.
     *
     * @param button the button to set as active
     */
    private void setActiveNav(JButton button) {
        if (activeNavButton != null) {
            activeNavButton.setBackground(UITheme.SIDEBAR_BG);
            activeNavButton.setForeground(UITheme.SIDEBAR_TEXT);
        }
        activeNavButton = button;
        activeNavButton.setBackground(UITheme.PRIMARY);
        activeNavButton.setForeground(UITheme.ACCENT);
    }

    /**
     * Shows the dashboard overview with stats cards.
     */
    private void showDashboard() {
        contentPanel.removeAll();

        JPanel dashPanel = new JPanel(new BorderLayout(0, 20));
        dashPanel.setOpaque(false);

        JLabel header = new JLabel("Dashboard Overview");
        header.setFont(UITheme.FONT_TITLE);
        header.setForeground(UITheme.TEXT_PRIMARY);
        dashPanel.add(header, BorderLayout.NORTH);

        // Stats cards
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 15, 0));
        statsRow.setOpaque(false);

        SwingWorker<int[], Void> worker = new SwingWorker<>() {
            @Override
            protected int[] doInBackground() {
                return new int[]{
                    electionController.countElections(),
                    adminController.countVoters(),
                    voteController.countAllVotes(),
                    electionController.countByStatus("active")
                };
            }

            @Override
            protected void done() {
                try {
                    int[] counts = get();
                    statsRow.add(UITheme.createStatsCard("Total Elections", String.valueOf(counts[0]), UITheme.PRIMARY));
                    statsRow.add(UITheme.createStatsCard("Total Voters", String.valueOf(counts[1]), UITheme.SUCCESS));
                    statsRow.add(UITheme.createStatsCard("Total Votes Cast", String.valueOf(counts[2]), UITheme.ACCENT));
                    statsRow.add(UITheme.createStatsCard("Active Elections", String.valueOf(counts[3]), UITheme.WARNING));
                    statsRow.revalidate();
                    statsRow.repaint();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();

        dashPanel.add(statsRow, BorderLayout.CENTER);
        contentPanel.add(dashPanel, BorderLayout.NORTH);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /** Shows the manage elections panel. */
    private void showElections() {
        contentPanel.removeAll();
        contentPanel.add(new ManageElectionsPanel(), BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /** Shows the manage candidates panel. */
    private void showCandidates() {
        contentPanel.removeAll();
        contentPanel.add(new ManageCandidatesPanel(), BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /** Shows the manage voters panel. */
    private void showVoters() {
        contentPanel.removeAll();
        contentPanel.add(new ManageVotersPanel(), BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /** Shows the reports panel. */
    private void showReports() {
        contentPanel.removeAll();
        contentPanel.add(new ReportsPanel(), BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /** Logs the user out and returns to login screen. */
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?", "Confirm Logout",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            new controller.AuthController().logout();
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}
