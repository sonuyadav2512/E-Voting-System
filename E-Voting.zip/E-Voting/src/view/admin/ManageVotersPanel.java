package view.admin;

import controller.AdminController;
import model.User;
import utils.DateUtil;
import utils.UITheme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Panel for managing voter registrations (approve, reject, delete, search).
 */
public class ManageVotersPanel extends JPanel {

    private JTable voterTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JComboBox<String> filterCombo;
    private final AdminController controller;

    /** Constructs the manage voters panel. */
    public ManageVotersPanel() {
        controller = new AdminController();
        initComponents();
        loadVoters();
    }

    /**
     * Initializes all UI components.
     */
    private void initComponents() {
        setLayout(new BorderLayout(0, 15));
        setOpaque(false);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout(10, 0));
        headerPanel.setOpaque(false);

        JLabel title = new JLabel("Manage Voters");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        headerPanel.add(title, BorderLayout.WEST);

        // Search & filter
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        searchPanel.setOpaque(false);

        searchField = UITheme.createTextField();
        searchField.setPreferredSize(new Dimension(200, 30));
        searchField.setToolTipText("Search by name or email");
        JButton searchButton = UITheme.createPrimaryButton("Search");

        filterCombo = new JComboBox<>(new String[]{"All", "Approved", "Pending"});
        filterCombo.setFont(UITheme.FONT_BODY);

        searchPanel.add(new JLabel("Filter:"));
        searchPanel.add(filterCombo);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        headerPanel.add(searchPanel, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Full Name", "Email", "Approved", "Registered"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        voterTable = new JTable(tableModel);
        voterTable.setFont(UITheme.FONT_TABLE);
        voterTable.setRowHeight(32);
        voterTable.getTableHeader().setFont(UITheme.FONT_BUTTON);
        voterTable.getTableHeader().setBackground(UITheme.PRIMARY);
        voterTable.getTableHeader().setForeground(Color.WHITE);
        voterTable.setSelectionBackground(UITheme.PRIMARY_LIGHT);
        voterTable.setSelectionForeground(Color.WHITE);
        voterTable.setGridColor(new Color(0xE0, 0xE0, 0xE0));

        JScrollPane scrollPane = new JScrollPane(voterTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0, 0xE0, 0xE0)));
        add(scrollPane, BorderLayout.CENTER);

        // Action buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        actionPanel.setOpaque(false);

        JButton approveButton = UITheme.createPrimaryButton("Approve");
        JButton rejectButton = UITheme.createAccentButton("Reject");
        JButton deleteButton = UITheme.createDangerButton("Delete");
        JButton bulkApproveButton = UITheme.createPrimaryButton("Bulk Approve Selected");
        JButton refreshButton = UITheme.createPrimaryButton("Refresh");

        actionPanel.add(approveButton);
        actionPanel.add(rejectButton);
        actionPanel.add(deleteButton);
        actionPanel.add(bulkApproveButton);
        actionPanel.add(refreshButton);
        add(actionPanel, BorderLayout.SOUTH);

        // Event handlers
        approveButton.addActionListener(e -> approveSelected());
        rejectButton.addActionListener(e -> rejectSelected());
        deleteButton.addActionListener(e -> deleteSelected());
        bulkApproveButton.addActionListener(e -> bulkApproveSelected());
        refreshButton.addActionListener(e -> loadVoters());
        searchButton.addActionListener(e -> searchVoters());
        filterCombo.addActionListener(e -> loadVoters());
        searchField.addActionListener(e -> searchVoters());
    }

    /**
     * Loads voters based on the filter selection.
     */
    private void loadVoters() {
        String filter = (String) filterCombo.getSelectedItem();
        SwingWorker<List<User>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<User> doInBackground() {
                switch (filter) {
                    case "Approved": return controller.getVotersByApproval(true);
                    case "Pending": return controller.getVotersByApproval(false);
                    default: return controller.getAllVoters();
                }
            }

            @Override
            protected void done() {
                try {
                    populateTable(get());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /**
     * Searches voters by keyword.
     */
    private void searchVoters() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadVoters();
            return;
        }
        SwingWorker<List<User>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<User> doInBackground() {
                return controller.searchVoters(keyword);
            }

            @Override
            protected void done() {
                try {
                    populateTable(get());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /**
     * Populates the table with voter data.
     *
     * @param voters the list of voters
     */
    private void populateTable(List<User> voters) {
        tableModel.setRowCount(0);
        for (User u : voters) {
            tableModel.addRow(new Object[]{
                u.getUserId(),
                u.getFullName(),
                u.getEmail(),
                u.isApproved() ? "Yes" : "No",
                DateUtil.formatDisplay(u.getCreatedAt())
            });
        }
    }

    /** Approves the selected voter. */
    private void approveSelected() {
        int row = voterTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a voter.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() {
                return controller.approveVoter(id);
            }

            @Override
            protected void done() {
                try {
                    if (get()) {
                        JOptionPane.showMessageDialog(ManageVotersPanel.this, "Voter approved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        loadVoters();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /** Rejects the selected voter. */
    private void rejectSelected() {
        int row = voterTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a voter.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() {
                return controller.rejectVoter(id);
            }

            @Override
            protected void done() {
                try {
                    if (get()) {
                        loadVoters();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /** Deletes the selected voter with confirmation. */
    private void deleteSelected() {
        int row = voterTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a voter.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        String name = (String) tableModel.getValueAt(row, 1);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete voter \"" + name + "\"? This cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() {
                    return controller.deleteVoter(id);
                }

                @Override
                protected void done() {
                    try {
                        if (get()) {
                            loadVoters();
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            worker.execute();
        }
    }

    /** Bulk approves all selected (pending) voters. */
    private void bulkApproveSelected() {
        int[] rows = voterTable.getSelectedRows();
        if (rows.length == 0) {
            JOptionPane.showMessageDialog(this, "Please select voters to approve.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        List<Integer> ids = new ArrayList<>();
        for (int row : rows) {
            String approved = (String) tableModel.getValueAt(row, 3);
            if ("No".equals(approved)) {
                ids.add((int) tableModel.getValueAt(row, 0));
            }
        }

        if (ids.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No pending voters selected.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Approve " + ids.size() + " voter(s)?",
                "Confirm Bulk Approve", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            SwingWorker<Integer, Void> worker = new SwingWorker<>() {
                @Override
                protected Integer doInBackground() {
                    return controller.bulkApprove(ids);
                }

                @Override
                protected void done() {
                    try {
                        int count = get();
                        JOptionPane.showMessageDialog(ManageVotersPanel.this,
                                count + " voter(s) approved.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        loadVoters();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            worker.execute();
        }
    }
}
