package view.admin;

import controller.ElectionController;
import controller.VoteController;
import model.Candidate;
import model.Election;
import utils.UITheme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Reports panel with election result table, bar chart, and CSV export.
 */
public class ReportsPanel extends JPanel {

    private JComboBox<Election> electionCombo;
    private JTable resultsTable;
    private DefaultTableModel tableModel;
    private JLabel totalVotesLabel;
    private ChartPanel chartPanel;
    private final ElectionController electionController;
    private final VoteController voteController;

    /** Constructs the reports panel. */
    public ReportsPanel() {
        electionController = new ElectionController();
        voteController = new VoteController();
        initComponents();
        loadElections();
    }

    /**
     * Initializes all UI components.
     */
    private void initComponents() {
        setLayout(new BorderLayout(0, 15));
        setOpaque(false);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel title = new JLabel("Election Reports");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        headerPanel.add(title, BorderLayout.WEST);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        controls.setOpaque(false);
        controls.add(new JLabel("Election:"));
        electionCombo = new JComboBox<>();
        electionCombo.setFont(UITheme.FONT_BODY);
        electionCombo.setPreferredSize(new Dimension(250, 35));
        controls.add(electionCombo);

        JButton exportButton = UITheme.createAccentButton("Export to CSV");
        exportButton.addActionListener(e -> exportCSV());
        controls.add(exportButton);

        headerPanel.add(controls, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Main content - split between table and chart
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(400);
        splitPane.setOpaque(false);

        // Table
        JPanel tablePanel = new JPanel(new BorderLayout(0, 10));
        tablePanel.setOpaque(false);

        String[] columns = {"Candidate", "Party", "Votes", "Percentage"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        resultsTable = new JTable(tableModel);
        resultsTable.setFont(UITheme.FONT_TABLE);
        resultsTable.setRowHeight(32);
        resultsTable.getTableHeader().setFont(UITheme.FONT_BUTTON);
        resultsTable.getTableHeader().setBackground(UITheme.PRIMARY);
        resultsTable.getTableHeader().setForeground(Color.WHITE);
        resultsTable.setGridColor(new Color(0xE0, 0xE0, 0xE0));

        JScrollPane scrollPane = new JScrollPane(resultsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0, 0xE0, 0xE0)));
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        totalVotesLabel = new JLabel("Total Votes: 0");
        totalVotesLabel.setFont(UITheme.FONT_SUBTITLE);
        totalVotesLabel.setForeground(UITheme.PRIMARY);
        tablePanel.add(totalVotesLabel, BorderLayout.SOUTH);

        splitPane.setLeftComponent(tablePanel);

        // Chart
        chartPanel = new ChartPanel();
        splitPane.setRightComponent(chartPanel);

        add(splitPane, BorderLayout.CENTER);

        // Event handlers
        electionCombo.addActionListener(e -> loadResults());
    }

    /**
     * Loads elections into the combo box.
     */
    private void loadElections() {
        SwingWorker<List<Election>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Election> doInBackground() {
                return electionController.getAllElections();
            }

            @Override
            protected void done() {
                try {
                    electionCombo.removeAllItems();
                    for (Election el : get()) {
                        electionCombo.addItem(el);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /**
     * Loads election results into the table and chart.
     */
    private void loadResults() {
        Election selected = (Election) electionCombo.getSelectedItem();
        if (selected == null) return;

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            private Map<Integer, Integer> results;
            private List<Candidate> candidates;
            private int totalVotes;

            @Override
            protected Void doInBackground() {
                results = voteController.getResults(selected.getElectionId());
                candidates = electionController.getCandidates(selected.getElectionId());
                totalVotes = voteController.countVotes(selected.getElectionId());
                return null;
            }

            @Override
            protected void done() {
                tableModel.setRowCount(0);
                String[] names = new String[candidates.size()];
                int[] votes = new int[candidates.size()];
                int i = 0;

                for (Candidate c : candidates) {
                    int voteCount = results.getOrDefault(c.getCandidateId(), 0);
                    double percentage = totalVotes > 0 ? (voteCount * 100.0 / totalVotes) : 0;
                    tableModel.addRow(new Object[]{
                        c.getFullName(),
                        c.getParty(),
                        voteCount,
                        String.format("%.1f%%", percentage)
                    });
                    names[i] = c.getFullName();
                    votes[i] = voteCount;
                    i++;
                }

                totalVotesLabel.setText("Total Votes: " + totalVotes);
                chartPanel.setData(names, votes);
            }
        };
        worker.execute();
    }

    /**
     * Exports results to a CSV file.
     */
    private void exportCSV() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No data to export.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save CSV");
        chooser.setSelectedFile(new File("election_results.csv"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try (FileWriter writer = new FileWriter(chooser.getSelectedFile())) {
                // Header
                writer.write("Candidate,Party,Votes,Percentage\n");
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    writer.write(String.format("\"%s\",\"%s\",%s,%s\n",
                            tableModel.getValueAt(i, 0),
                            tableModel.getValueAt(i, 1),
                            tableModel.getValueAt(i, 2),
                            tableModel.getValueAt(i, 3)));
                }
                writer.write("\n" + totalVotesLabel.getText() + "\n");
                JOptionPane.showMessageDialog(this, "CSV exported successfully!", "Export Complete", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Failed to export CSV: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Custom panel that draws a bar chart using Java2D.
     */
    private static class ChartPanel extends JPanel {

        private String[] names = {};
        private int[] votes = {};

        private static final Color[] BAR_COLORS = {
            new Color(0x1A, 0x23, 0x7E), new Color(0xFF, 0xD7, 0x00),
            new Color(0x4C, 0xAF, 0x50), new Color(0xF4, 0x43, 0x36),
            new Color(0x21, 0x96, 0xF3), new Color(0xFF, 0x57, 0x22),
            new Color(0x9C, 0x27, 0xB0), new Color(0x00, 0x96, 0x88)
        };

        /**
         * Sets the chart data and triggers a repaint.
         *
         * @param names candidate names
         * @param votes vote counts
         */
        public void setData(String[] names, int[] votes) {
            this.names = names;
            this.votes = votes;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (names.length == 0) return;

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();
            int padding = 50;
            int chartWidth = width - padding * 2;
            int chartHeight = height - padding * 2 - 30;

            // Title
            g2.setFont(UITheme.FONT_SUBTITLE);
            g2.setColor(UITheme.TEXT_PRIMARY);
            g2.drawString("Vote Distribution", padding, 25);

            // Find max votes
            int maxVotes = 1;
            for (int v : votes) {
                maxVotes = Math.max(maxVotes, v);
            }

            // Draw bars
            int barWidth = Math.min(60, (chartWidth - 20) / Math.max(names.length, 1) - 10);
            int gap = (chartWidth - barWidth * names.length) / (names.length + 1);

            for (int i = 0; i < names.length; i++) {
                int barHeight = (int) ((double) votes[i] / maxVotes * chartHeight);
                int x = padding + gap + i * (barWidth + gap);
                int y = padding + 30 + chartHeight - barHeight;

                // Bar
                Color barColor = BAR_COLORS[i % BAR_COLORS.length];
                g2.setColor(barColor);
                g2.fillRoundRect(x, y, barWidth, barHeight, 6, 6);

                // Vote count
                g2.setColor(UITheme.TEXT_PRIMARY);
                g2.setFont(UITheme.FONT_BUTTON);
                String voteStr = String.valueOf(votes[i]);
                int textWidth = g2.getFontMetrics().stringWidth(voteStr);
                g2.drawString(voteStr, x + (barWidth - textWidth) / 2, y - 5);

                // Name label
                g2.setFont(UITheme.FONT_SMALL);
                g2.setColor(UITheme.TEXT_SECONDARY);
                String name = names[i].length() > 10 ? names[i].substring(0, 10) + ".." : names[i];
                int nameWidth = g2.getFontMetrics().stringWidth(name);
                g2.drawString(name, x + (barWidth - nameWidth) / 2, height - 15);
            }

            // Axes
            g2.setColor(new Color(0xBD, 0xBD, 0xBD));
            g2.drawLine(padding, padding + 30, padding, height - padding);
            g2.drawLine(padding, height - padding, width - padding, height - padding);
        }
    }
}
