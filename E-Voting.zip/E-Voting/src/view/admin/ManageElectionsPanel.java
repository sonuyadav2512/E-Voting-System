package view.admin;

import controller.ElectionController;
import model.Election;
import utils.DateUtil;
import utils.UITheme;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Date;
import java.util.List;

/**
 * Panel for managing elections (CRUD) with a JTable display.
 */
public class ManageElectionsPanel extends JPanel {

    private JTable electionTable;
    private DefaultTableModel tableModel;
    private final ElectionController controller;

    /** Constructs the manage elections panel. */
    public ManageElectionsPanel() {
        controller = new ElectionController();
        initComponents();
        loadElections();
    }

    /**
     * Initializes and lays out all UI components.
     */
    private void initComponents() {
        setLayout(new BorderLayout(0, 15));
        setOpaque(false);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel title = new JLabel("Manage Elections");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        headerPanel.add(title, BorderLayout.WEST);

        JButton addButton = UITheme.createPrimaryButton("+ Add Election");
        addButton.addActionListener(e -> showElectionDialog(null));
        headerPanel.add(addButton, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Title", "Start Date", "End Date", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        electionTable = new JTable(tableModel);
        electionTable.setFont(UITheme.FONT_TABLE);
        electionTable.setRowHeight(32);
        electionTable.getTableHeader().setFont(UITheme.FONT_BUTTON);
        electionTable.getTableHeader().setBackground(UITheme.PRIMARY);
        electionTable.getTableHeader().setForeground(Color.WHITE);
        electionTable.setSelectionBackground(UITheme.PRIMARY_LIGHT);
        electionTable.setSelectionForeground(Color.WHITE);
        electionTable.setGridColor(new Color(0xE0, 0xE0, 0xE0));

        JScrollPane scrollPane = new JScrollPane(electionTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(0xE0, 0xE0, 0xE0)));
        add(scrollPane, BorderLayout.CENTER);

        // Action buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        actionPanel.setOpaque(false);

        JButton editButton = UITheme.createAccentButton("Edit");
        JButton deleteButton = UITheme.createDangerButton("Delete");
        JButton statusButton = UITheme.createPrimaryButton("Change Status");
        JButton refreshButton = UITheme.createPrimaryButton("Refresh");

        actionPanel.add(editButton);
        actionPanel.add(deleteButton);
        actionPanel.add(statusButton);
        actionPanel.add(refreshButton);
        add(actionPanel, BorderLayout.SOUTH);

        // Event handlers
        editButton.addActionListener(e -> editSelected());
        deleteButton.addActionListener(e -> deleteSelected());
        statusButton.addActionListener(e -> changeStatusSelected());
        refreshButton.addActionListener(e -> loadElections());
    }

    /**
     * Loads elections from the database into the table.
     */
    private void loadElections() {
        SwingWorker<List<Election>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Election> doInBackground() {
                return controller.getAllElections();
            }

            @Override
            protected void done() {
                try {
                    List<Election> elections = get();
                    tableModel.setRowCount(0);
                    for (Election el : elections) {
                        tableModel.addRow(new Object[]{
                            el.getElectionId(),
                            el.getTitle(),
                            DateUtil.formatDisplay(el.getStartDate()),
                            DateUtil.formatDisplay(el.getEndDate()),
                            el.getStatus().toUpperCase()
                        });
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /**
     * Shows the add/edit election dialog.
     *
     * @param election the election to edit, or null for a new one
     */
    private void showElectionDialog(Election election) {
        boolean isEdit = (election != null);
        JDialog dialog = new JDialog(SwingUtilities.getWindowAncestor(this),
                isEdit ? "Edit Election" : "Add Election",
                Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setSize(450, 450);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.insets = new Insets(5, 5, 5, 5);

        JTextField titleField = UITheme.createTextField();
        JTextArea descArea = new JTextArea(3, 20);
        descArea.setFont(UITheme.FONT_BODY);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        JSpinner startSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner endSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor startEditor = new JSpinner.DateEditor(startSpinner, DateUtil.DATETIME_FORMAT);
        JSpinner.DateEditor endEditor = new JSpinner.DateEditor(endSpinner, DateUtil.DATETIME_FORMAT);
        startSpinner.setEditor(startEditor);
        endSpinner.setEditor(endEditor);
        JComboBox<String> statusCombo = new JComboBox<>(new String[]{"upcoming", "active", "closed"});

        if (isEdit) {
            titleField.setText(election.getTitle());
            descArea.setText(election.getDescription());
            startSpinner.setValue(election.getStartDate());
            endSpinner.setValue(election.getEndDate());
            statusCombo.setSelectedItem(election.getStatus());
        }

        int row = 0;
        gbc.gridy = row++;
        panel.add(new JLabel("Title:"), gbc);
        gbc.gridy = row++;
        panel.add(titleField, gbc);
        gbc.gridy = row++;
        panel.add(new JLabel("Description:"), gbc);
        gbc.gridy = row++;
        panel.add(new JScrollPane(descArea), gbc);
        gbc.gridy = row++;
        panel.add(new JLabel("Start Date:"), gbc);
        gbc.gridy = row++;
        panel.add(startSpinner, gbc);
        gbc.gridy = row++;
        panel.add(new JLabel("End Date:"), gbc);
        gbc.gridy = row++;
        panel.add(endSpinner, gbc);
        gbc.gridy = row++;
        panel.add(new JLabel("Status:"), gbc);
        gbc.gridy = row++;
        panel.add(statusCombo, gbc);

        JButton saveButton = UITheme.createPrimaryButton(isEdit ? "Update" : "Save");
        gbc.gridy = row;
        gbc.insets = new Insets(15, 5, 5, 5);
        panel.add(saveButton, gbc);

        dialog.setContentPane(new JScrollPane(panel));

        saveButton.addActionListener(e -> {
            String t = titleField.getText().trim();
            if (t.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Title is required.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Date start = (Date) startSpinner.getValue();
            Date end = (Date) endSpinner.getValue();
            if (end.before(start)) {
                JOptionPane.showMessageDialog(dialog, "End date must be after start date.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Election el = isEdit ? election : new Election();
            el.setTitle(t);
            el.setDescription(descArea.getText().trim());
            el.setStartDate(start);
            el.setEndDate(end);
            el.setStatus((String) statusCombo.getSelectedItem());

            SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() {
                    return isEdit ? controller.updateElection(el) : controller.createElection(el);
                }

                @Override
                protected void done() {
                    try {
                        if (get()) {
                            dialog.dispose();
                            loadElections();
                        } else {
                            JOptionPane.showMessageDialog(dialog, "Operation failed.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            worker.execute();
        });

        dialog.setVisible(true);
    }

    /** Opens the edit dialog for the selected election. */
    private void editSelected() {
        int row = electionTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an election to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        SwingWorker<Election, Void> worker = new SwingWorker<>() {
            @Override
            protected Election doInBackground() {
                return controller.getElection(id);
            }

            @Override
            protected void done() {
                try {
                    Election el = get();
                    if (el != null) {
                        showElectionDialog(el);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /** Deletes the selected election with confirmation. */
    private void deleteSelected() {
        int row = electionTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an election to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        String title = (String) tableModel.getValueAt(row, 1);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete \"" + title + "\"?\nThis will also delete all associated candidates and votes.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() {
                    return controller.deleteElection(id);
                }

                @Override
                protected void done() {
                    try {
                        if (get()) {
                            loadElections();
                        } else {
                            JOptionPane.showMessageDialog(ManageElectionsPanel.this, "Failed to delete election.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            worker.execute();
        }
    }

    /** Changes the status of the selected election. */
    private void changeStatusSelected() {
        int row = electionTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an election.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        String[] statuses = {"upcoming", "active", "closed"};
        String newStatus = (String) JOptionPane.showInputDialog(this,
                "Select new status:", "Change Status",
                JOptionPane.PLAIN_MESSAGE, null, statuses, statuses[0]);
        if (newStatus != null) {
            SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() {
                    return controller.changeElectionStatus(id, newStatus);
                }

                @Override
                protected void done() {
                    try {
                        if (get()) {
                            loadElections();
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            worker.execute();
        }
    }
}
