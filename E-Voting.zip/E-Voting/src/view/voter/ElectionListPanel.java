package view.voter;

import controller.ElectionController;
import controller.VoteController;
import model.Election;
import utils.DateUtil;
import utils.UITheme;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Panel displaying available elections as cards for the voter.
 * Shows active elections the voter hasn't voted in, and vote history.
 */
public class ElectionListPanel extends JPanel {

    private final ElectionController electionController;
    private final VoteController voteController;
    private final VoterDashboard parentDashboard;

    /**
     * Constructs the election list panel.
     *
     * @param parent the parent voter dashboard
     */
    public ElectionListPanel(VoterDashboard parent) {
        this.parentDashboard = parent;
        this.electionController = new ElectionController();
        this.voteController = new VoteController();
        initComponents();
    }

    /**
     * Initializes all UI components and loads elections.
     */
    private void initComponents() {
        setLayout(new BorderLayout(0, 20));
        setOpaque(false);

        JLabel header = new JLabel("Elections");
        header.setFont(UITheme.FONT_TITLE);
        header.setForeground(UITheme.TEXT_PRIMARY);
        add(header, BorderLayout.NORTH);

        JPanel containerPanel = new JPanel();
        containerPanel.setLayout(new BoxLayout(containerPanel, BoxLayout.Y_AXIS));
        containerPanel.setOpaque(false);

        JScrollPane scrollPane = new JScrollPane(containerPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane, BorderLayout.CENTER);

        // Load data in background
        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            private List<Election> activeElections;
            private List<Election> allElections;
            private List<Integer> votedElectionIds;

            @Override
            protected Void doInBackground() {
                allElections = electionController.getAllElections();
                activeElections = electionController.getElectionsByStatus("active");
                votedElectionIds = voteController.getVotedElectionIds();
                return null;
            }

            @Override
            protected void done() {
                // Active Elections Section
                JLabel activeHeader = new JLabel("  Active Elections");
                activeHeader.setFont(UITheme.FONT_SUBTITLE);
                activeHeader.setForeground(UITheme.SUCCESS);
                activeHeader.setAlignmentX(Component.LEFT_ALIGNMENT);
                containerPanel.add(activeHeader);
                containerPanel.add(Box.createVerticalStrut(10));

                boolean hasActive = false;
                for (Election el : activeElections) {
                    boolean hasVoted = votedElectionIds.contains(el.getElectionId());
                    containerPanel.add(createElectionCard(el, hasVoted));
                    containerPanel.add(Box.createVerticalStrut(10));
                    hasActive = true;
                }
                if (!hasActive) {
                    JLabel noActive = new JLabel("    No active elections at this time.");
                    noActive.setFont(UITheme.FONT_BODY);
                    noActive.setForeground(UITheme.TEXT_SECONDARY);
                    noActive.setAlignmentX(Component.LEFT_ALIGNMENT);
                    containerPanel.add(noActive);
                    containerPanel.add(Box.createVerticalStrut(10));
                }

                containerPanel.add(Box.createVerticalStrut(20));

                // Vote History Section
                JLabel historyHeader = new JLabel("  My Vote History");
                historyHeader.setFont(UITheme.FONT_SUBTITLE);
                historyHeader.setForeground(UITheme.PRIMARY);
                historyHeader.setAlignmentX(Component.LEFT_ALIGNMENT);
                containerPanel.add(historyHeader);
                containerPanel.add(Box.createVerticalStrut(10));

                boolean hasHistory = false;
                for (Election el : allElections) {
                    if (votedElectionIds.contains(el.getElectionId())) {
                        containerPanel.add(createElectionCard(el, true));
                        containerPanel.add(Box.createVerticalStrut(10));
                        hasHistory = true;
                    }
                }
                if (!hasHistory) {
                    JLabel noHistory = new JLabel("    You haven't voted in any election yet.");
                    noHistory.setFont(UITheme.FONT_BODY);
                    noHistory.setForeground(UITheme.TEXT_SECONDARY);
                    noHistory.setAlignmentX(Component.LEFT_ALIGNMENT);
                    containerPanel.add(noHistory);
                }

                containerPanel.revalidate();
                containerPanel.repaint();
            }
        };
        worker.execute();
    }

    /**
     * Creates a card panel for an election.
     *
     * @param election the election data
     * @param hasVoted whether the voter has already voted
     * @return a styled card JPanel
     */
    private JPanel createElectionCard(Election election, boolean hasVoted) {
        JPanel card = UITheme.createCardPanel();
        card.setLayout(new BorderLayout(15, 5));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Left: election info
        JPanel infoPanel = new JPanel(new GridLayout(4, 1, 0, 3));
        infoPanel.setOpaque(false);

        JLabel titleLabel = new JLabel(election.getTitle());
        titleLabel.setFont(UITheme.FONT_SUBTITLE);
        titleLabel.setForeground(UITheme.TEXT_PRIMARY);

        JLabel descLabel = new JLabel(election.getDescription() != null
                ? (election.getDescription().length() > 100
                    ? election.getDescription().substring(0, 100) + "..."
                    : election.getDescription())
                : "No description");
        descLabel.setFont(UITheme.FONT_BODY);
        descLabel.setForeground(UITheme.TEXT_SECONDARY);

        JLabel dateLabel = new JLabel("Ends: " + DateUtil.formatDisplay(election.getEndDate()));
        dateLabel.setFont(UITheme.FONT_SMALL);
        dateLabel.setForeground(UITheme.TEXT_SECONDARY);

        int candidateCount = electionController.countCandidates(election.getElectionId());
        JLabel candidatesLabel = new JLabel("Candidates: " + candidateCount);
        candidatesLabel.setFont(UITheme.FONT_SMALL);
        candidatesLabel.setForeground(UITheme.TEXT_SECONDARY);

        infoPanel.add(titleLabel);
        infoPanel.add(descLabel);
        infoPanel.add(dateLabel);
        infoPanel.add(candidatesLabel);

        card.add(infoPanel, BorderLayout.CENTER);

        // Right: action
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 15));
        actionPanel.setOpaque(false);

        if (hasVoted) {
            JLabel votedBadge = new JLabel("Already Voted \u2713");
            votedBadge.setFont(UITheme.FONT_BUTTON);
            votedBadge.setForeground(UITheme.SUCCESS);
            votedBadge.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UITheme.SUCCESS, 2),
                    BorderFactory.createEmptyBorder(6, 12, 6, 12)
            ));
            actionPanel.add(votedBadge);
        } else if ("active".equals(election.getStatus())) {
            JButton voteButton = UITheme.createPrimaryButton("Vote Now");
            voteButton.addActionListener(e -> parentDashboard.showVotingPanel(election.getElectionId()));
            actionPanel.add(voteButton);
        } else {
            JLabel statusLabel = new JLabel(election.getStatus().toUpperCase());
            statusLabel.setFont(UITheme.FONT_BUTTON);
            statusLabel.setForeground(UITheme.TEXT_SECONDARY);
            actionPanel.add(statusLabel);
        }

        card.add(actionPanel, BorderLayout.EAST);

        return card;
    }
}
