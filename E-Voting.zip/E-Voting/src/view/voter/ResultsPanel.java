package view.voter;

import controller.ElectionController;
import controller.VoteController;
import model.Candidate;
import model.Election;
import utils.UITheme;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Map;

/**
 * Results panel for voters to view results of closed elections.
 * Shows the same bar chart as the admin reports panel (read-only).
 */
public class ResultsPanel extends JPanel {

    private JComboBox<Election> electionCombo;
    private ResultChartPanel chartPanel;
    private JLabel totalVotesLabel;
    private final ElectionController electionController;
    private final VoteController voteController;

    /** Constructs the results panel. */
    public ResultsPanel() {
        electionController = new ElectionController();
        voteController = new VoteController();
        initComponents();
        loadClosedElections();
    }

    /**
     * Initializes all UI components.
     */
    private void initComponents() {
        setLayout(new BorderLayout(0, 15));
        setOpaque(false);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel title = new JLabel("Election Results");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        headerPanel.add(title, BorderLayout.WEST);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        controls.setOpaque(false);
        controls.add(new JLabel("Closed Elections:"));
        electionCombo = new JComboBox<>();
        electionCombo.setFont(UITheme.FONT_BODY);
        electionCombo.setPreferredSize(new Dimension(250, 35));
        controls.add(electionCombo);
        headerPanel.add(controls, BorderLayout.EAST);

        add(headerPanel, BorderLayout.NORTH);

        // Chart
        chartPanel = new ResultChartPanel();
        add(chartPanel, BorderLayout.CENTER);

        // Total votes
        totalVotesLabel = new JLabel("Total Votes: 0");
        totalVotesLabel.setFont(UITheme.FONT_SUBTITLE);
        totalVotesLabel.setForeground(UITheme.PRIMARY);
        totalVotesLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        add(totalVotesLabel, BorderLayout.SOUTH);

        // Events
        electionCombo.addActionListener(e -> loadResults());
    }

    /**
     * Loads only closed elections into the combo box.
     */
    private void loadClosedElections() {
        SwingWorker<List<Election>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Election> doInBackground() {
                return electionController.getElectionsByStatus("closed");
            }

            @Override
            protected void done() {
                try {
                    electionCombo.removeAllItems();
                    List<Election> elections = get();
                    if (elections.isEmpty()) {
                        totalVotesLabel.setText("No closed elections available.");
                    }
                    for (Election el : elections) {
                        electionCombo.addItem(el);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /**
     * Loads results for the selected election.
     */
    private void loadResults() {
        Election selected = (Election) electionCombo.getSelectedItem();
        if (selected == null) return;

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            private Map<Integer, Integer> results;
            private List<Candidate> candidates;
            private int totalVotes;

            @Override
            protected Void doInBackground() {
                results = voteController.getResults(selected.getElectionId());
                candidates = electionController.getCandidates(selected.getElectionId());
                totalVotes = voteController.countVotes(selected.getElectionId());
                return null;
            }

            @Override
            protected void done() {
                String[] names = new String[candidates.size()];
                int[] votes = new int[candidates.size()];
                for (int i = 0; i < candidates.size(); i++) {
                    Candidate c = candidates.get(i);
                    names[i] = c.getFullName();
                    votes[i] = results.getOrDefault(c.getCandidateId(), 0);
                }
                chartPanel.setData(names, votes);
                totalVotesLabel.setText("Total Votes: " + totalVotes);
            }
        };
        worker.execute();
    }

    /**
     * Custom panel that draws a bar chart using Java2D (same as admin reports).
     */
    private static class ResultChartPanel extends JPanel {

        private String[] names = {};
        private int[] votes = {};

        private static final Color[] BAR_COLORS = {
            new Color(0x1A, 0x23, 0x7E), new Color(0xFF, 0xD7, 0x00),
            new Color(0x4C, 0xAF, 0x50), new Color(0xF4, 0x43, 0x36),
            new Color(0x21, 0x96, 0xF3), new Color(0xFF, 0x57, 0x22),
            new Color(0x9C, 0x27, 0xB0), new Color(0x00, 0x96, 0x88)
        };

        /**
         * Sets the chart data and triggers a repaint.
         *
         * @param names candidate names
         * @param votes vote counts
         */
        public void setData(String[] names, int[] votes) {
            this.names = names;
            this.votes = votes;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (names.length == 0) {
                g.setFont(UITheme.FONT_BODY);
                g.setColor(UITheme.TEXT_SECONDARY);
                g.drawString("Select an election to view results", 50, getHeight() / 2);
                return;
            }

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();
            int padding = 50;
            int chartWidth = width - padding * 2;
            int chartHeight = height - padding * 2 - 30;

            // Title
            g2.setFont(UITheme.FONT_SUBTITLE);
            g2.setColor(UITheme.TEXT_PRIMARY);
            g2.drawString("Vote Distribution", padding, 25);

            // Find max votes
            int maxVotes = 1;
            for (int v : votes) {
                maxVotes = Math.max(maxVotes, v);
            }

            // Draw bars
            int barWidth = Math.min(60, (chartWidth - 20) / Math.max(names.length, 1) - 10);
            int gap = (chartWidth - barWidth * names.length) / (names.length + 1);

            for (int i = 0; i < names.length; i++) {
                int barHeight = (int) ((double) votes[i] / maxVotes * chartHeight);
                int x = padding + gap + i * (barWidth + gap);
                int y = padding + 30 + chartHeight - barHeight;

                Color barColor = BAR_COLORS[i % BAR_COLORS.length];
                g2.setColor(barColor);
                g2.fillRoundRect(x, y, barWidth, barHeight, 6, 6);

                g2.setColor(UITheme.TEXT_PRIMARY);
                g2.setFont(UITheme.FONT_BUTTON);
                String voteStr = String.valueOf(votes[i]);
                int textWidth = g2.getFontMetrics().stringWidth(voteStr);
                g2.drawString(voteStr, x + (barWidth - textWidth) / 2, y - 5);

                g2.setFont(UITheme.FONT_SMALL);
                g2.setColor(UITheme.TEXT_SECONDARY);
                String name = names[i].length() > 10 ? names[i].substring(0, 10) + ".." : names[i];
                int nameWidth = g2.getFontMetrics().stringWidth(name);
                g2.drawString(name, x + (barWidth - nameWidth) / 2, height - 15);
            }

            // Axes
            g2.setColor(new Color(0xBD, 0xBD, 0xBD));
            g2.drawLine(padding, padding + 30, padding, height - padding);
            g2.drawLine(padding, height - padding, width - padding, height - padding);
        }
    }
}
