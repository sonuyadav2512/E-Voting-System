package view.voter;

import controller.ElectionController;
import controller.VoteController;
import model.Candidate;
import model.Election;
import utils.UITheme;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.List;

/**
 * Voting panel that displays candidates as radio-button cards
 * and allows the voter to cast a vote with confirmation.
 */
public class VotingPanel extends JPanel {

    private final int electionId;
    private final VoterDashboard parentDashboard;
    private final ElectionController electionController;
    private final VoteController voteController;
    private ButtonGroup candidateGroup;
    private JButton confirmButton;

    /**
     * Constructs the voting panel.
     *
     * @param electionId the election to vote in
     * @param parent     the parent voter dashboard
     */
    public VotingPanel(int electionId, VoterDashboard parent) {
        this.electionId = electionId;
        this.parentDashboard = parent;
        this.electionController = new ElectionController();
        this.voteController = new VoteController();
        initComponents();
    }

    /**
     * Initializes all UI components.
     */
    private void initComponents() {
        setLayout(new BorderLayout(0, 15));
        setOpaque(false);

        // Check if already voted
        if (voteController.hasVoted(electionId)) {
            JLabel alreadyVoted = new JLabel("You have already voted in this election.");
            alreadyVoted.setFont(UITheme.FONT_TITLE);
            alreadyVoted.setForeground(UITheme.SUCCESS);
            alreadyVoted.setHorizontalAlignment(SwingConstants.CENTER);
            add(alreadyVoted, BorderLayout.CENTER);

            JButton backButton = UITheme.createPrimaryButton("Back to Elections");
            backButton.addActionListener(e -> parentDashboard.showElectionList());
            JPanel backPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            backPanel.setOpaque(false);
            backPanel.add(backButton);
            add(backPanel, BorderLayout.SOUTH);
            return;
        }

        // Load election details
        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            private Election election;
            private List<Candidate> candidates;

            @Override
            protected Void doInBackground() {
                election = electionController.getElection(electionId);
                candidates = electionController.getCandidates(electionId);
                return null;
            }

            @Override
            protected void done() {
                if (election == null) return;

                // Header
                JPanel headerPanel = new JPanel(new GridLayout(2, 1, 0, 5));
                headerPanel.setOpaque(false);

                JLabel titleLabel = new JLabel(election.getTitle());
                titleLabel.setFont(UITheme.FONT_TITLE);
                titleLabel.setForeground(UITheme.PRIMARY);

                JLabel descLabel = new JLabel(election.getDescription() != null ? election.getDescription() : "");
                descLabel.setFont(UITheme.FONT_BODY);
                descLabel.setForeground(UITheme.TEXT_SECONDARY);

                headerPanel.add(titleLabel);
                headerPanel.add(descLabel);
                add(headerPanel, BorderLayout.NORTH);

                // Candidate cards
                JPanel candidatesPanel = new JPanel();
                candidatesPanel.setLayout(new BoxLayout(candidatesPanel, BoxLayout.Y_AXIS));
                candidatesPanel.setOpaque(false);

                candidateGroup = new ButtonGroup();

                for (Candidate c : candidates) {
                    JPanel card = createCandidateCard(c);
                    candidatesPanel.add(card);
                    candidatesPanel.add(Box.createVerticalStrut(10));
                }

                JScrollPane scrollPane = new JScrollPane(candidatesPanel);
                scrollPane.setBorder(BorderFactory.createEmptyBorder());
                scrollPane.getVerticalScrollBar().setUnitIncrement(16);
                scrollPane.setOpaque(false);
                scrollPane.getViewport().setOpaque(false);
                add(scrollPane, BorderLayout.CENTER);

                // Bottom buttons
                JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
                bottomPanel.setOpaque(false);

                JButton backButton = UITheme.createAccentButton("Back");
                backButton.addActionListener(e -> parentDashboard.showElectionList());

                confirmButton = UITheme.createPrimaryButton("Confirm Vote");
                confirmButton.setPreferredSize(new Dimension(180, UITheme.BUTTON_HEIGHT));
                confirmButton.addActionListener(e -> confirmVote(candidates));

                bottomPanel.add(backButton);
                bottomPanel.add(confirmButton);
                add(bottomPanel, BorderLayout.SOUTH);

                revalidate();
                repaint();
            }
        };
        worker.execute();
    }

    /**
     * Creates a styled candidate card with a radio button.
     *
     * @param candidate the candidate data
     * @return the candidate card panel
     */
    private JPanel createCandidateCard(Candidate candidate) {
        JPanel card = UITheme.createCardPanel();
        card.setLayout(new BorderLayout(15, 0));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Radio button
        JRadioButton radio = new JRadioButton();
        radio.setOpaque(false);
        radio.setActionCommand(String.valueOf(candidate.getCandidateId()));
        candidateGroup.add(radio);

        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 25));
        radioPanel.setOpaque(false);
        radioPanel.add(radio);
        card.add(radioPanel, BorderLayout.WEST);

        // Photo
        JLabel photoLabel = new JLabel();
        photoLabel.setPreferredSize(new Dimension(70, 70));
        photoLabel.setBorder(BorderFactory.createLineBorder(UITheme.PRIMARY_LIGHT, 2));
        photoLabel.setHorizontalAlignment(SwingConstants.CENTER);

        if (candidate.getPhotoPath() != null && new File(candidate.getPhotoPath()).exists()) {
            try {
                ImageIcon icon = new ImageIcon(candidate.getPhotoPath());
                Image img = icon.getImage().getScaledInstance(70, 70, Image.SCALE_SMOOTH);
                photoLabel.setIcon(new ImageIcon(img));
            } catch (Exception e) {
                photoLabel.setText("No Photo");
                photoLabel.setFont(UITheme.FONT_SMALL);
            }
        } else {
            photoLabel.setText("No Photo");
            photoLabel.setFont(UITheme.FONT_SMALL);
            photoLabel.setForeground(UITheme.TEXT_SECONDARY);
        }

        card.add(photoLabel, BorderLayout.EAST);

        // Info
        JPanel infoPanel = new JPanel(new GridLayout(3, 1, 0, 2));
        infoPanel.setOpaque(false);

        JLabel nameLabel = new JLabel(candidate.getFullName());
        nameLabel.setFont(UITheme.FONT_SUBTITLE);
        nameLabel.setForeground(UITheme.TEXT_PRIMARY);

        JLabel partyLabel = new JLabel(candidate.getParty() != null ? candidate.getParty() : "Independent");
        partyLabel.setFont(UITheme.FONT_BODY);
        partyLabel.setForeground(UITheme.PRIMARY);

        JLabel bioLabel = new JLabel(candidate.getBio() != null
                ? (candidate.getBio().length() > 80 ? candidate.getBio().substring(0, 80) + "..." : candidate.getBio())
                : "");
        bioLabel.setFont(UITheme.FONT_SMALL);
        bioLabel.setForeground(UITheme.TEXT_SECONDARY);

        infoPanel.add(nameLabel);
        infoPanel.add(partyLabel);
        infoPanel.add(bioLabel);

        card.add(infoPanel, BorderLayout.CENTER);

        // Click card to select radio
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        card.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                radio.setSelected(true);
            }
        });

        return card;
    }

    /**
     * Confirms the vote with a dialog and casts it.
     *
     * @param candidates the list of candidates
     */
    private void confirmVote(List<Candidate> candidates) {
        ButtonModel selection = candidateGroup.getSelection();
        if (selection == null) {
            JOptionPane.showMessageDialog(this, "Please select a candidate.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int candidateId = Integer.parseInt(selection.getActionCommand());
        String candidateName = "";
        for (Candidate c : candidates) {
            if (c.getCandidateId() == candidateId) {
                candidateName = c.getFullName();
                break;
            }
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "You are voting for \"" + candidateName + "\".\nThis cannot be undone. Are you sure?",
                "Confirm Vote", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            confirmButton.setEnabled(false);
            confirmButton.setText("Casting vote...");

            SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
                @Override
                protected Boolean doInBackground() {
                    return voteController.castVote(electionId, candidateId);
                }

                @Override
                protected void done() {
                    confirmButton.setEnabled(true);
                    confirmButton.setText("Confirm Vote");
                    try {
                        if (get()) {
                            JOptionPane.showMessageDialog(VotingPanel.this,
                                    "Your vote has been cast successfully!\nThank you for participating.",
                                    "Vote Successful", JOptionPane.INFORMATION_MESSAGE);
                            // Go back to election list
                            parentDashboard.showElectionList();
                        } else {
                            JOptionPane.showMessageDialog(VotingPanel.this,
                                    "Failed to cast vote. You may have already voted.",
                                    "Vote Failed", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(VotingPanel.this,
                                "An error occurred while casting your vote.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        ex.printStackTrace();
                    }
                }
            };
            worker.execute();
        }
    }
}
