package view.voter;

import controller.AuthController;
import model.User;
import utils.SessionManager;
import utils.UITheme;
import view.LoginFrame;

import javax.swing.*;
import java.awt.*;

/**
 * Voter dashboard with active elections and vote history sections.
 */
public class VoterDashboard extends JFrame {

    private JPanel contentPanel;
    private final User currentUser;

    /**
     * Constructs the voter dashboard.
     */
    public VoterDashboard() {
        this.currentUser = SessionManager.getCurrentUser();
        initComponents();
    }

    /**
     * Initializes and lays out all UI components.
     */
    private void initComponents() {
        setTitle("E-Voting System - Voter Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 650);
        setMinimumSize(new Dimension(800, 550));
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UITheme.BG_LIGHT);

        // ─── Top Bar ────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UITheme.PRIMARY);
        topBar.setPreferredSize(new Dimension(0, 55));
        topBar.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JLabel welcomeLabel = new JLabel("Welcome, " + (currentUser != null ? currentUser.getFullName() : "Voter"));
        welcomeLabel.setFont(UITheme.FONT_SUBTITLE);
        welcomeLabel.setForeground(Color.WHITE);
        topBar.add(welcomeLabel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        rightPanel.setOpaque(false);

        JButton electionsBtn = UITheme.createAccentButton("Active Elections");
        JButton resultsBtn = UITheme.createPrimaryButton("View Results");
        JButton logoutButton = UITheme.createDangerButton("Logout");
        logoutButton.setPreferredSize(new Dimension(90, 32));

        rightPanel.add(electionsBtn);
        rightPanel.add(resultsBtn);
        rightPanel.add(logoutButton);
        topBar.add(rightPanel, BorderLayout.EAST);

        mainPanel.add(topBar, BorderLayout.NORTH);

        // ─── Content Area ──────────────────────────
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(UITheme.BG_LIGHT);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        setContentPane(mainPanel);

        // Show election list by default
        showElectionList();

        // Event handlers
        electionsBtn.addActionListener(e -> showElectionList());
        resultsBtn.addActionListener(e -> showResults());
        logoutButton.addActionListener(e -> logout());
    }

    /**
     * Shows the election list panel.
     */
    public void showElectionList() {
        contentPanel.removeAll();
        contentPanel.add(new ElectionListPanel(this), BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /**
     * Shows the voting panel for a specific election.
     *
     * @param electionId the election ID
     */
    public void showVotingPanel(int electionId) {
        contentPanel.removeAll();
        contentPanel.add(new VotingPanel(electionId, this), BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /**
     * Shows the results panel.
     */
    private void showResults() {
        contentPanel.removeAll();
        contentPanel.add(new ResultsPanel(), BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    /**
     * Logs out and returns to the login screen.
     */
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?", "Confirm Logout",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            new AuthController().logout();
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}
